﻿/* FILE : Globals.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains global variables used in the program
*/

namespace HCVService
{
    static class Globals
    {
        public const int HC_LENGTH = 12;
        public const int BYTE_BUFFER_SIZE = 1024;
        public const int PORT = 2019;
        public const int PAUSE_TIME = 4000;
        public const int HCV_NUMBER_PORTION = 10;
        public const int HCV_CODE_PORTION = 2;
    }
}
