﻿/* FILE : DAL.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains the code to access the HC DB
*/

using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace HCVService
{
    public static class DAL
    {

        // Variable that holds the connection string
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["HCVConnectionString"].ConnectionString;

        /* METHOD : CheckHCV
         DESCRIPTION : This method checks to see if there are any health cards that match what was sent by EMS
         PARAMETERS : string healthCard
         RETURNS : string - If card was found, return the card. If not, return blank
        */

        public static DataTable GetCards()
        {
            using (var myConn = new SqlConnection(ConnectionString))
            {
                const string getCardsQuery = @"SELECT Card_Num, Card_Code FROM Health_Cards";

                // Create the insert command
                var getCardsCommand = new SqlCommand(getCardsQuery, myConn);

                // Open the connection
                myConn.Open();

                var reader = getCardsCommand.ExecuteReader();

                DataTable cards = new DataTable();

                cards.Load(reader);

                return cards;
            }       
        }
    }
}
