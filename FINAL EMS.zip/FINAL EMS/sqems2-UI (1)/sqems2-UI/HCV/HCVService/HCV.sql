/*
*FILE :				HCV.sql
*PROJECT :			EMS-II
*PROGRAMMER :		Blake Ribble
*FIRST VERSION :	2019-03-21
*DESCRIPTION :		This script creates a small database called HealthCardValidator that only holds encrypted health card numbers
*/

-- Create DB
CREATE DATABASE HealthCardValidator

GO

-- Use the DB
USE HealthCardValidator

-- Create the table
CREATE TABLE Health_Cards
(
	Card_ID int IDENTITY,
	Card_Num nvarchar(100),
	Card_Code nvarchar(100)
);
