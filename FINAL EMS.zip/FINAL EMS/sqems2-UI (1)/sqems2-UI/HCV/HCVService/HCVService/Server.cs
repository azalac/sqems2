﻿/* FILE : Server.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains the server methods behind getting the input and returning it to user
*/

using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using EMS_Security;
using System.Data;

namespace HCVService
{
    class Server
    {
        // Public variable to set if server is running or not
        public bool Run { set; get; }

        // Public variable to set if server is paused or not
        public bool Pause { set; get; }

        /* CONSTUCTOR : Server
         DESCRIPTION : This sets the server to run
         PARAMETERS : NONE
         RETURNS : NONE
        */

        public Server()
        {
            Run = true;
        }

        /* METHOD : RunServer
         DESCRIPTION : This method contains the socket to connect with client and process input
         PARAMETERS : NONE
         RETURNS : NONE
        */

        public void RunServer()
        {
            // Declare and initialize variables
            byte[] byteBuffer = new byte[Globals.BYTE_BUFFER_SIZE];
            string data = "";
            string encryptedData = "";

            //Get the hostName, ipAddress and endpoint of the computer
            int port = Globals.PORT;
            IPAddress ipAddress = IPAddress.Parse(GetLocalIPAddress());
            IPEndPoint endpoint = new IPEndPoint(ipAddress, port);

            //Create a new server socket connection for server
            Socket serverSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //Create the client handler socket
            Socket clientHandler;

            //Bind the socket to the endpoint
            serverSocket.Bind(endpoint);

            //Listen for incoming client connections
            serverSocket.Listen(1);

            while(true)
            {
                //Waits until a client joins
                clientHandler = serverSocket.Accept();

                // Set a timer for receiving a message
                clientHandler.ReceiveTimeout = 40000;

                // While the server is running
                while (Run)
                {
                    //Set data to null to ensure no data leaks
                    data = "";
                    encryptedData = "";

                    //Recieve a message from the client
                    int bytesRecieved;

                    try
                    {
                        bytesRecieved = clientHandler.Receive(byteBuffer);
                    }

                    catch (Exception)
                    {
                        //If the server has been paused
                        while (Pause)
                        {
                            //Sleep until pause is off
                            Thread.Sleep(4000);
                        }

                        //If the server has shut off
                        if (Run == false)
                        {
                            //Break out of the loop
                            break;
                        }

                        //If the server hasn't stopped, go back to the start to wait again for a message
                        else
                        {
                            continue;
                        }
                    }

                    //Convert the message into a string
                    encryptedData = Encoding.ASCII.GetString(byteBuffer, 0, bytesRecieved);

                    // Decrypt the data
                    data = Encryption.Decrypt(encryptedData);

                    // If the client is leaving
                    if (data == "BYE")
                    {
                        break;
                    }
                  
                    //Extract the number portion out of the string
                    string numbers = data.Substring(0, Globals.HCV_NUMBER_PORTION);

                    //Extract the version code out of the string
                    string code = data.Substring(Globals.HCV_NUMBER_PORTION, Globals.HCV_CODE_PORTION);

                    DataTable healthCards = new DataTable();

                    healthCards = DAL.GetCards();

                    int response = CheckRequest(numbers, code, healthCards);

                    if(response == 1)
                    {
                        byte[] msg = Encoding.ASCII.GetBytes("VALID");

                        clientHandler.Send(msg);
                    }
                    else if (response == 2)
                    {
                        byte[] msg = Encoding.ASCII.GetBytes("VCODE");

                        clientHandler.Send(msg);
                    }
                    else
                    {
                        byte[] msg = Encoding.ASCII.GetBytes("PUNKO");

                        clientHandler.Send(msg);
                    }                            
                }
            }           
        }

        private int CheckRequest(string number, string code, DataTable healthCards)
        {
            for(int i = 0; i < healthCards.Rows.Count; i++)
            {
                string decryptedNum = Encryption.Decrypt(healthCards.Rows[i]["Card_Num"].ToString());

                if(number == decryptedNum)
                {
                    string decryptedCode = Encryption.Decrypt(healthCards.Rows[i]["Card_Code"].ToString());

                    if (code == decryptedCode)
                    {
                        return 1;
                    }
                    else
                    {
                        return 2;
                    }
                }
            }

            return 3;
        }

        /* METHOD : GetLocalIPAddress
          DESCRIPTION : This function gets the IPV4 IP
          PARAMETERS : none
          RETURNS : string
        */

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    Logger.Log(ip.ToString());
                    return ip.ToString();
                    
                }
            }
            return "ERROR";
        }

        /* METHOD : StopServer
         DESCRIPTION : This function sets Run to false, meaning the server is ending
         PARAMETERS : none
         RETURNS : void
       */
        public void StopServer()
        {
            Run = false;
        }

        /* METHOD : PauseServer
          DESCRIPTION : This function sets Pause to true, meaning the server is pausing
          PARAMETERS : none
          RETURNS : void
       */
        public void PauseServer()
        {
            Pause = true;
        }

        /* METHOD : ContinueServer
          DESCRIPTION : This function sets Pause to false, meaning the server is continuing
          PARAMETERS : none
          RETURNS : void
       */
        public void ContinueServer()
        {
            Pause = false;
        }
    }
}
