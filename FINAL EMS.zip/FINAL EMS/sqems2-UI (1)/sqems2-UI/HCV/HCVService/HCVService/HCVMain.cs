﻿/* FILE : HCVMain.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains the entry point for the service
*/

using System;
using System.ServiceProcess;

namespace HCVService
{
    static class HCVMain
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new HCVService()
            };
            ServiceBase.Run(ServicesToRun);
        }

    }
}
