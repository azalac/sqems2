﻿/* FILE : DAL.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-04-22
*DESCRIPTION : This file contains the code to add sample data to the HCV DB
*/

using System;
using System.Configuration;
using System.Data.SqlClient;

namespace InsertIntoHCV
{
    public static class DAL
    {

        // Variable that holds the connection string
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["HCVConnectionString"].ConnectionString;

        /* METHOD : InsertToDB
         DESCRIPTION : This method inserts the enter health card into the DB
         PARAMETERS : string healthCard
         RETURNS : VOID
        */

        public static void InsertToDB(string healthCardNum, string healthCardCode)
        {                   
            using (var myConn = new SqlConnection(ConnectionString))
            {
                const string insertCardQuery = @"INSERT INTO Health_Cards VALUES (@cardNum, @cardCode)";

                // Create the insert command
                var insertCardCommand = new SqlCommand(insertCardQuery, myConn);

                // Open the connection
                myConn.Open();

                insertCardCommand.Parameters.AddWithValue("@cardNum", healthCardNum);
                insertCardCommand.Parameters.AddWithValue("@cardCode", healthCardCode);

                insertCardCommand.ExecuteNonQuery();
            }        
        }
    }
}
