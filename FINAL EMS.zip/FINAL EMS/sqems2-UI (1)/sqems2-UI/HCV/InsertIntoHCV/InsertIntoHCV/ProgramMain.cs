﻿/* FILE : ProgramMain.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-04-22
*DESCRIPTION : This file contains the loop that takes user input, encrypts it, and adds to DB
*/

using System;
using EMS_Security;

namespace InsertIntoHCV
{
    public static class ProgramMain
    {
        /* METHOD : Main
         DESCRIPTION : This method contains the code to execute all code
         PARAMETERS : string[] args
         RETURNS : VOID
        */

        static void Main(string[] args)
        {
            while(true)
            {
                Console.Write("Enter Health Card Number (10 characters): ");
                string HCN = Console.ReadLine();
                string EncryptedHCN = Encryption.Encrypt(HCN);

                Console.Write("Enter Health Card Code (2 characters): ");
                string HCC = Console.ReadLine();
                string EncryptedHCC = Encryption.Encrypt(HCC);

                DAL.InsertToDB(EncryptedHCN, EncryptedHCC);

                Console.WriteLine("HCN added to HCV DB\n\n");
            }         
        }
    }
}
