﻿/* FILE : Logger.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains the logic behind logging the response to a text file
*/

using System.Diagnostics;

namespace HCVService
{
    static class Logger
    {
        /* METHOD : Log
         DESCRIPTION : This method logs the server status
         PARAMETERS : string message
         RETURNS : void
        */

        public static void Log(string message)
        {
            EventLog serviceEventLog = new EventLog();
            if(!EventLog.SourceExists("MyEventSource"))
            {
                EventLog.CreateEventSource("MyEventSource", "MyEventLog");
            }
            serviceEventLog.Source = "MyEventSource";
            serviceEventLog.Log = "MyEventLog";
            serviceEventLog.WriteEntry(message);
        }
    }
}
