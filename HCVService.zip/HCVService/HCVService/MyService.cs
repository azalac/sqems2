﻿/* FILE : MyService.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This contains the service methods needed to change state
*/

using System.ServiceProcess;
using System.Threading;

namespace HCVService
{
    public partial class MyService : ServiceBase
    {
        // Declare instances for use in project
        Thread HCVThread = null;
        HCVServer server = null;

        /* CONSTRUCTOR : MyService
           DESCRIPTION : This server constructor creates a new server thread to be executed when the service starts
           PARAMETERS : None
           RETURNS : None
        */

        public MyService()
        {
            InitializeComponent();

            CanPauseAndContinue = true;

            // Instantiate the server
            server = new HCVServer();

            // Create a new server thread
            ThreadStart ts = new ThreadStart(server.RunServer);
            HCVThread = new Thread(ts);
        }

        /* METHOD : OnStart
         DESCRIPTION : This method logs that the service is starting, and starts the server thread
         PARAMETERS : string[] args
         RETURNS : void
        */

        protected override void OnStart(string[] args)
        {
            EventLogger.LogServerStatus("Server has started");
            HCVThread.Start();
        }

        /* FUNCTION : OnStop
          DESCRIPTION : This function logs that the service is stopping, and ends the server thread
          PARAMETERS : none
          RETURNS : void
        */

        protected override void OnStop()
        {
            EventLogger.LogServerStatus("Server told to stop");

            server.Run = false;

            HCVThread.Join();

            EventLogger.LogServerStatus("Server has stopped");
        }

        /* FUNCTION : OnContinue
          DESCRIPTION : This function logs that the service is continuing, then continues the server
          PARAMETERS : none
          RETURNS : void
       */

        protected override void OnContinue()
        {
            EventLogger.LogServerStatus("Server has continued");

            server.Pause = false;
        }

        /* FUNCTION : OnPause
         DESCRIPTION : This function logs that the service is pausing, then pauses the server
         PARAMETERS : none
         RETURNS : void
       */

        protected override void OnPause()
        {
            EventLogger.LogServerStatus("Server has paused");

            server.Pause = true;
        }
    }
}
