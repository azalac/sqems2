﻿/* FILE : EventLogger.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains the logic behind logging the response to a text file
*/

using System;
using System.IO;

namespace HCVService
{
    public static class EventLogger
    {
        /* METHOD : Log
         DESCRIPTION : This method takes the client input and logs the response to a text file
         PARAMETERS : string message, string code
         RETURNS : void
        */

        public static void Log(string message, string code)
        {
            //Allows for the writing of the logs in the executable file
            string filePath = AppDomain.CurrentDomain.BaseDirectory + "EventLog.txt";

            //Gets the current time of day
            string currentTime = CurrentTime();

            //Append the incoming request to the text file
            using (StreamWriter sw = File.AppendText(filePath))
            {
                //Write to the log file
                sw.WriteLine(currentTime);
                sw.WriteLine("Code Received: " + message);
                sw.WriteLine("Response Code Issued: " + code + "\n");
            }
        }

        /* METHOD : Log
         DESCRIPTION : Method that writes to the same file as above but only contains one message
         PARAMETERS : string message, string code
         RETURNS : void
        */

        public static void LogServerStatus(string message)
        {
            //Allows for the writing of the logs in the executable file
            string filePath = AppDomain.CurrentDomain.BaseDirectory + "EventLog.txt";

            //Gets the current time of day
            string currentTime = CurrentTime();

            //Append the incoming request to the text file
            using (StreamWriter sw = File.AppendText(filePath))
            {
                //Write to the log file
                sw.WriteLine(currentTime);
                sw.WriteLine("Code Received: " + message + "\n");            
            }
        }

        /* METHOD : CurrentTime
           DESCRIPTION : This method gets the current time
           PARAMETERS : void
           RETURNS : string
        */

        private static string CurrentTime()
        {
            DateTime utcDate = DateTime.UtcNow;

            string time = utcDate.ToString();

            return time;
        }
    }
}
