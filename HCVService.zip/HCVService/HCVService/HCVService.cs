﻿/* FILE : HCVService.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This contains the service methods needed to change state
*/

using System.ServiceProcess;
using System.Threading;

namespace HCVService
{
    public partial class HCVService : ServiceBase
    {

        // Declare instances for use in project
        Thread HCVThread = null;
        Server server = null;

        /* CONSTRUCTOR : HCVService
           DESCRIPTION : This server constructor creates a new server thread to be executed when the service starts
           PARAMETERS : None
           RETURNS : None
        */

        public HCVService()
        {
            InitializeComponent();
            CanPauseAndContinue = true;

            // Instantiate the server
            server = new Server();

            // Create a new server thread
            ThreadStart ts = new ThreadStart(server.RunServer);
            HCVThread = new Thread(ts);
        }

        /* METHOD : OnStart
         DESCRIPTION : This method logs that the service is starting, and starts the server thread
         PARAMETERS : string[] args
         RETURNS : void
        */

        protected override void OnStart(string[] args)
        {
            Logger.Log("Started");
            HCVThread.Start();
        }

        /* FUNCTION : OnStop
          DESCRIPTION : This function logs that the service is stopping, and ends the server thread
          PARAMETERS : none
          RETURNS : void
        */

        protected override void OnStop()
        {
            Logger.Log("Ending");

            server.Run = false;

            HCVThread.Join();
        }

        /* FUNCTION : OnContinue
          DESCRIPTION : This function logs that the service is continuing, then continues the server
          PARAMETERS : none
          RETURNS : void
        */

        protected override void OnContinue()
        {
            Logger.Log("Resuming");

            server.Pause = false;
        }

        /* FUNCTION : OnPause
         DESCRIPTION : This function logs that the service is pausing, then pauses the server
         PARAMETERS : none
         RETURNS : void
        */

        protected override void OnPause()
        {
            Logger.Log("Pausing");

            server.Pause = true;
        }
    }
}
