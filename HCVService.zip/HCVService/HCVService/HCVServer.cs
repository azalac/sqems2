﻿/* FILE : HCVServer.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains the server methods behind getting the input and returning it to user
*/

using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.IO;
using System;

namespace HCVService
{
    public class HCVServer
    {
        // Public variable to set if server is running or not
        public bool Run { set; get; }

        // Public variable to set if server is paused or not
        public bool Pause { set; get; }

        /* CONSTUCTOR : HCVServer
         DESCRIPTION : This sets the server to run
         PARAMETERS : NONE
         RETURNS : NONE
        */

        public HCVServer()
        {
            Run = true;
        }

        /* METHOD : RunServer
         DESCRIPTION : This method contains the socket to connect with client and process input
         PARAMETERS : NONE
         RETURNS : NONE
        */

        public void RunServer()
        {
            // Declare and initialize variables
            byte[] byteBuffer = new byte[1024];
            string data = "";

            //Get the hostName, ipAddress and endpoint of the computer
            int port = 5050;
            IPAddress ipAddress = IPAddress.Parse(GetLocalIPAddress());
            IPEndPoint endpoint = new IPEndPoint(ipAddress, port);

            //Create a new server socket connection for server
            Socket serverSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //Create the client handler socket
            Socket clientHandler;

            //Bind the socket to the endpoint
            serverSocket.Bind(endpoint);

            //Listen for incoming client connections
            serverSocket.Listen(15);

            //Waits until a client joins
            clientHandler = serverSocket.Accept();

            // While the server is running
            while (Run)
            {
                //Set data to null to ensure no data leaks
                data = null;

                // If the server is paused
                while (Pause)
                {
                    Thread.Sleep(4000);
                }

                //Recieve a message from the client
                int bytesRecieved = clientHandler.Receive(byteBuffer);

                //Convert the message into a string
                data += Encoding.ASCII.GetString(byteBuffer, 0, bytesRecieved);

                //Create regex for first 10 numbers and two character version code
                var numberRegex = new Regex(@"^[1-9]\d{9}$");
                var codeRegex = new Regex(@"^[A-Z]{2}$");

                //If the health card is the valid length
                if (data.Length == 12)
                {
                    //Extract the number portion out of the string
                    string numbers = data.Substring(0, 10);

                    //Extract the version code out of the string
                    string code = data.Substring(10, 2);

                    //If the user entered a valid number combination
                    if (numberRegex.IsMatch(numbers))
                    {
                        //If the two character version code is valid
                        if (codeRegex.IsMatch(code))
                        {

                            //If the health card was found
                            if (SearchHealthCard(data) == 1)
                            {

                                byte[] msg = Encoding.ASCII.GetBytes("VALID");

                                clientHandler.Send(msg);
                            }

                            //If the health card is valid, but was not found
                            else
                            {

                                byte[] msg = Encoding.ASCII.GetBytes("FUNKO");

                                clientHandler.Send(msg);
                            }
                        }

                        //If the version code is incorrect
                        else
                        {
                            byte[] msg = Encoding.ASCII.GetBytes("VCODE");

                            clientHandler.Send(msg);
                        }
                    }

                    //If the number portion is invalid
                    else
                    {
                        EventLogger.Log("Invalid Number Portion", data);

                        byte[] response = Encoding.ASCII.GetBytes("Invalid Number Portion");
                        clientHandler.Send(response);
                    }
                }

                //If the length of string is invalid
                else
                {
                    EventLogger.Log("Invalid Length", data);
                    byte[] response = Encoding.ASCII.GetBytes("Invalid Length");
                    clientHandler.Send(response);
                }
            }
        }

        /* METHOD : SearchHealthCard
           DESCRIPTION : Searchs the health card text file to check if health card is in "database"
           PARAMETERS : string data
           RETURNS : bool
        */

        private static int SearchHealthCard(string data)
        {
                int found = 0;

                // Create the path where the health cards will be
                string path = AppDomain.CurrentDomain.BaseDirectory + "../../HealthCards.txt";

                // Store any possible health cards values into a string array
                string[] AllHealthCards = File.ReadAllLines(path);

                // Loop through each line and check to see if the line matches data
                foreach (string hc in AllHealthCards)
                {
                    // If match
                    if (hc == data)
                    {
                        found = 1;
                    }
                }

                // If it was found
                if (found == 1)
                {
                    return 1;
                }

                else
                {
                    return 2;
                }                      
        }

        /* METHOD : StopServer
         DESCRIPTION : This function sets Run to false, meaning the server is ending
         PARAMETERS : none
         RETURNS : void
       */
        public void StopServer()
        {
            Run = false;
        }

        /* METHOD : PauseServer
          DESCRIPTION : This function sets Pause to true, meaning the server is pausing
          PARAMETERS : none
          RETURNS : void
       */
        public void PauseServer()
        {
            Pause = true;
        }

        /* METHOD : ContinueServer
          DESCRIPTION : This function sets Pause to false, meaning the server is continuing
          PARAMETERS : none
          RETURNS : void
       */
        public void ContinueServer()
        {
            Pause = false;
        }

        /* METHOD : GetLocalIPAddress
          DESCRIPTION : This function gets the IPV4 IP
          PARAMETERS : none
          RETURNS : string
       */

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "ERROR";
        }
    }
}
