﻿/* FILE : ProjectInstaller.cs
*PROJECT : EMS-II
*PROGRAMMER : Odysseus
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This file contains the code behind the installer
*/

using System.ComponentModel;

namespace HCVService
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }
    }
}
