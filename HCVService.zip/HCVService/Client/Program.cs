﻿/* FILE : Client
*PROJECT : EMS-2 (TEST CLIENT)
*PROGRAMMER : Blake Ribble
*FIRST VERSION : 2019-03-21
*DESCRIPTION : This test application allows the user to enter a health card number and get a response back
*/

using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Client
{
    class Program
    {
        /* METHOD : Main
           DESCRIPTION : Calls the method which handles the incoming information
           PARAMETERS : string[] args
           RETURNS : none
        */

        static void Main(string[] args)
        {
            // Default port to connect to
            int port = 5050;

            // For client to connect (in our case EMS), get the IP of service and put it into a text file
            IPAddress ipAddress = IPAddress.Parse(IPAddressFromTextFile());

            // Create an endpoint
            IPEndPoint endpoint = new IPEndPoint(ipAddress, port);

            // Call the handleClient function
            HandleClient(ipAddress, endpoint);
        }

        /* METHOD : HandleClient
           DESCRIPTION : Method that allows user to enter a health card number and get a response back
           PARAMETERS : string[] args
           RETURNS : none
        */
        private static void HandleClient(IPAddress ipAddress, IPEndPoint endpoint)
        {
            //Create a byte buffer which will be used later on by the server
            byte[] byteBuffer = new byte[1024];

            //Another byte buffer which is used when sending a message to server
            byte[] msg;

            //int which will hold the number of bytes that were sent
            int bytesSent;

            //int which will hold the number of bytes that were recieved from server
            int bytesRec;

            //Create a new client socket connection
            Socket clientSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //Connect to the server through the endpoint
            clientSocket.Connect(endpoint);

            // Loop forever
            while(true)
            {
                Console.Write("Please enter hcv: ");
                string message = Console.ReadLine();

                //Send information over
                msg = Encoding.ASCII.GetBytes(message);

                // Send the message
                bytesSent = clientSocket.Send(msg);

                // Sleep so the client doesn't catch the message right away
                Thread.Sleep(10);

                //Recieve response from server
                bytesRec = clientSocket.Receive(byteBuffer);

                //Print data to result
                Console.WriteLine(Encoding.ASCII.GetString(byteBuffer, 0, bytesRec));
            }
        }

        /* METHOD : IPAddressFromTextFile
           DESCRIPTION : Method that gets the first line of a text file containing the IP and return it
           PARAMETERS : void
           RETURNS : string
        */

        public static string IPAddressFromTextFile()
        {
            //Allows for the writing of the logs in the executable file
            string filePath = "../../HCVIPAddress.txt";

            // Read all lines into a string array
            string[] contentArray = File.ReadAllLines(filePath);

            // Return the first line
            return contentArray[0];
        }
    }
}
