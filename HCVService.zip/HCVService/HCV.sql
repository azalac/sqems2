/*
*FILE :				HCV.sql
*PROJECT :			EMS-II
*PROGRAMMER :		Blake Ribble
*FIRST VERSION :	2019-03-21
*DESCRIPTION :		This script creates a small database called HealthCardValidator that only holds encrypted health card numbers
*/

-- Create DB
CREATE DATABASE HealthCardValidator

GO

-- Use the DB
USE HealthCardValidator

-- Create the table
CREATE TABLE Health_Cards
(
	Card_ID int IDENTITY,
	Card_Value nvarchar(100)
);

-- Add the sample values
INSERT INTO Health_Cards (Card_Value) VALUES
('B9F5483817E841080C969B40591A7B0B'),
('6467DFA2D7C3BFC8E6A4442DAB80A4B8');
