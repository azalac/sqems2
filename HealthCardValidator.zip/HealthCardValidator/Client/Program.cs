﻿/* FILE : Client
*PROJECT : EMS-2 (TEST CLIENT)
*PROGRAMMER : Blake Ribble
*FIRST VERSION : 2019-01-11
*DESCRIPTION : This test application allows the user to enter a health card number and get a response back
*/

using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Client
{
    class Program
    {
        /* METHOD : Main
           DESCRIPTION : Calls the method which handles the incoming information
           PARAMETERS : string[] args
           RETURNS : none
        */

        static void Main(string[] args)
        {
            int port = 5050;

            //Get the hostName, ipAddress and endpoint of the computer
            IPHostEntry hostName = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = hostName.AddressList[0];
            IPEndPoint endpoint = new IPEndPoint(ipAddress, port);

            //Call the handleClient function
            HandleClient(ipAddress, endpoint);
        }

        /* METHOD : HandleClient
           DESCRIPTION : Method that allows user to enter a health card number and get a response back
           PARAMETERS : string[] args
           RETURNS : none
        */
        private static void HandleClient(IPAddress ipAddress, IPEndPoint endpoint)
        {
            //Create a byte buffer which will be used later on by the server
            byte[] byteBuffer = new byte[1024];

            //Another byte buffer which is used when sending a message to server
            byte[] msg;

            //int which will hold the number of bytes that were sent
            int bytesSent;

            //int which will hold the number of bytes that were recieved from server
            int bytesRec;

            //Create a new client socket connection
            Socket clientSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //Connect to the server through the endpoint
            clientSocket.Connect(endpoint);

            while(true)
            {
                Console.Write("Please enter hcv: ");
                string message = Console.ReadLine();

                //Send information over
                msg = Encoding.ASCII.GetBytes(message);

                bytesSent = clientSocket.Send(msg);

                Thread.Sleep(5);

                //Recieve response from server
                bytesRec = clientSocket.Receive(byteBuffer);

                //Print data to result
                Console.WriteLine(Encoding.ASCII.GetString(byteBuffer, 0, bytesRec));
            }
        }    
    }
}
