﻿/* FILE : Health Card Validator
*PROJECT : EMS-2
*PROGRAMMER : Blake Ribble
*FIRST VERSION : 2019-01-11
*DESCRIPTION : This application takes the health card number provided and determines if its is valid, error in version code, or is valid but an unknown number
*/

using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace HealthCardValidator
{
    class Program
    {
        /* METHOD : Main
           DESCRIPTION : Calls the method which handles the incoming information
           PARAMETERS : string[] args
           RETURNS : none
        */

        static void Main(string[] args)
        {
            //Call Method
            HealthCardValidation();           
        }

        /* METHOD : HealthCardValidation
           DESCRIPTION : Handles the health card validation and returns the correct response
           PARAMETERS : none
           RETURNS : none
        */
        private static void HealthCardValidation()
        {
            // Declare and initialize variables
            byte[] byteBuffer = new byte[1024];
            string data = "";

            //Get the hostName, ipAddress and endpoint of the computer
            int port = 5050;
            IPHostEntry hostName = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = hostName.AddressList[0];
            IPEndPoint endpoint = new IPEndPoint(ipAddress, port);

            //Create a new server socket connection for server
            Socket serverSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //Create the client handler socket
            Socket clientHandler;

            //Bind the socket to the endpoint
            serverSocket.Bind(endpoint);

            //Listen for incoming client connections
            serverSocket.Listen(15);

            //Waits until a client joins
            clientHandler = serverSocket.Accept();

            while (true)
            {
                //Set data to null to ensure no data leaks
                data = null;

                //Recieve a message from the client
                int bytesRecieved = clientHandler.Receive(byteBuffer);

                //Convert the message into a string
                data += Encoding.ASCII.GetString(byteBuffer, 0, bytesRecieved);

                //Create regex for first 10 numbers and two character version code
                var numberRegex = new Regex(@"^[1-9]\d{9}$");
                var codeRegex = new Regex(@"^[A-Z]{2}$");

                //If the health card is the valid length
                if (data.Length == 12)
                {
                    //Extract the number portion out of the string
                    string numbers = data.Substring(0, 10);

                    //Extract the version code out of the string
                    string code = data.Substring(10, 2);

                    //If the user entered a valid number combination
                    if (numberRegex.IsMatch(numbers))
                    {
                        //If the two character version code is valid
                        if (codeRegex.IsMatch(code))
                        {
                            //If the health card was found
                            if(SearchHealthCard(data) == true)
                            {
                                byte[] msg = Encoding.ASCII.GetBytes("VALID");

                                clientHandler.Send(msg);
                            }

                            //If the health card is valid, but was not found
                            else
                            {
                                byte[] msg = Encoding.ASCII.GetBytes("PUNKO");

                                clientHandler.Send(msg);
                            }
                        }

                        //If the version code is incorrect
                        else
                        {
                            byte[] msg = Encoding.ASCII.GetBytes("VCODE");

                            clientHandler.Send(msg);
                        }
                    }

                    //If the numbre portion is invalid
                    else
                    {
                        Console.WriteLine("Invalid Number Portion");
                        Console.WriteLine(numbers.Length);
                    }
                }

                //If the length of string is invalid
                else
                {
                    Console.WriteLine("Invalid Length");
                }

            }
        }

        /* METHOD : SearchHealthCard
           DESCRIPTION : Searchs the health card text file to check if health card is in "database"
           PARAMETERS : string data
           RETURNS : bool
        */

        private static bool SearchHealthCard(string data)
        {
            int found = 0;
            string path = "../../HealthCards.txt";
            string[] AllHealthCards = File.ReadAllLines(path);

            foreach(string hc in AllHealthCards)
            {
                if(hc == data)
                {
                    found = 1;
                }
            }

            if(found == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
